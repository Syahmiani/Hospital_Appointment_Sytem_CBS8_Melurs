<?php
session_start();
require '../config/db.php';

if (empty($_SESSION['user'])) {
    header('Location: ../login.php'); exit;
}

$uid = $_SESSION['user']['user_id'];
$user_type = $_SESSION['user']['user_type'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['app_id'])) {
    die('Invalid request');
}

$app_id = intval($_POST['app_id']);

// Verify ownership based on user type
if ($user_type === 'patient') {
    $sql_check = "SELECT a.App_ID, a.App_Date, a.App_Time, a.symptom, a.status, a.payment_status,
                         ud.f_name AS doc_fname, ud.l_name AS doc_lname, d.specialization, d.room_no,
                         up.f_name AS pat_fname, up.l_name AS pat_lname, up.phone AS pat_phone, up.email AS pat_email,
                         s.Service_Name, s.Service_Price
                  FROM appointment a
                  JOIN doctor d ON a.doctor_id = d.doctor_id
                  JOIN user ud ON d.user_id = ud.user_id
                  JOIN patient p ON a.patient_id = p.patient_id
                  JOIN user up ON p.user_id = up.user_id
                  JOIN services s ON a.Service_ID = s.Service_ID
                  WHERE a.App_ID = ? AND p.user_id = ? AND (a.is_deleted IS NULL OR a.is_deleted = 0)";
    $stmt_check = mysqli_prepare($conn, $sql_check);
    mysqli_stmt_bind_param($stmt_check, 'ii', $app_id, $uid);
} elseif ($user_type === 'doctor') {
    $sql_check = "SELECT a.App_ID, a.App_Date, a.App_Time, a.symptom, a.status, a.payment_status,
                         ud.f_name AS doc_fname, ud.l_name AS doc_lname, d.specialization, d.room_no,
                         up.f_name AS pat_fname, up.l_name AS pat_lname, up.phone AS pat_phone, up.email AS pat_email,
                         s.Service_Name, s.Service_Price
                  FROM appointment a
                  JOIN doctor d ON a.doctor_id = d.doctor_id
                  JOIN user ud ON d.user_id = ud.user_id
                  JOIN patient p ON a.patient_id = p.patient_id
                  JOIN user up ON p.user_id = up.user_id
                  JOIN services s ON a.Service_ID = s.Service_ID
                  WHERE a.App_ID = ? AND d.user_id = ? AND (a.is_deleted IS NULL OR a.is_deleted = 0)";
    $stmt_check = mysqli_prepare($conn, $sql_check);
    mysqli_stmt_bind_param($stmt_check, 'ii', $app_id, $uid);
} else {
    die('Unauthorized access');
}

mysqli_stmt_execute($stmt_check);
$result = mysqli_stmt_get_result($stmt_check);

if (mysqli_num_rows($result) === 0) {
    die('Appointment not found or access denied');
}

$appointment = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt_check);

// Fetch prescribed medicines
$prescriptions = [];
$sql_presc = "SELECT m.med_name, m.med_price, p.quantity
              FROM prescription p
              JOIN medicine m ON p.med_id = m.med_id
              WHERE p.App_ID = ?";
$stmt_presc = mysqli_prepare($conn, $sql_presc);
mysqli_stmt_bind_param($stmt_presc, 'i', $app_id);
mysqli_stmt_execute($stmt_presc);
$res_presc = mysqli_stmt_get_result($stmt_presc);
while ($row = mysqli_fetch_assoc($res_presc)) {
    $prescriptions[] = $row;
}
mysqli_stmt_close($stmt_presc);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Appointment Details - ID: <?php echo htmlspecialchars($appointment['App_ID']); ?></title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #007BFF;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            color: #007BFF;
        }
        .details {
            margin-bottom: 20px;
        }
        .details table {
            width: 100%;
            border-collapse: collapse;
        }
        .details th, .details td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .details th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .medicines {
            margin-top: 20px;
        }
        .medicines h3 {
            color: #007BFF;
            border-bottom: 1px solid #007BFF;
            padding-bottom: 5px;
        }
        .medicines ul {
            list-style-type: none;
            padding: 0;
        }
        .medicines li {
            padding: 5px 0;
            border-bottom: 1px solid #eee;
        }
        .total {
            font-weight: bold;
            color: #007BFF;
            margin-top: 10px;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>HOSPITAL APPOINTMENT DETAILS</h1>
        <p>Appointment ID: <?php echo htmlspecialchars($appointment['App_ID']); ?></p>
    </div>

    <div class="details">
        <table>
            <tr>
                <th>Patient Name:</th>
                <td><?php echo htmlspecialchars($appointment['pat_fname'] . ' ' . $appointment['pat_lname']); ?></td>
            </tr>
            <tr>
                <th>Doctor:</th>
                <td>Dr. <?php echo htmlspecialchars($appointment['doc_fname'] . ' ' . $appointment['doc_lname']); ?> (<?php echo htmlspecialchars($appointment['specialization']); ?>)</td>
            </tr>
            <tr>
                <th>Room:</th>
                <td><?php echo htmlspecialchars($appointment['room_no']); ?></td>
            </tr>
            <tr>
                <th>Appointment Date:</th>
                <td><?php echo htmlspecialchars(date('d-M-Y', strtotime($appointment['App_Date']))); ?></td>
            </tr>
            <tr>
                <th>Appointment Time:</th>
                <td><?php echo htmlspecialchars($appointment['App_Time']); ?></td>
            </tr>
            <tr>
                <th>Symptoms:</th>
                <td><?php echo htmlspecialchars($appointment['symptom']); ?></td>
            </tr>
            <tr>
                <th>Service:</th>
                <td><?php echo htmlspecialchars($appointment['Service_Name']); ?> - RM <?php echo number_format($appointment['Service_Price'], 2); ?></td>
            </tr>
            <tr>
                <th>Status:</th>
                <td><?php echo htmlspecialchars(ucfirst($appointment['status'])); ?></td>
            </tr>
            <tr>
                <th>Payment Status:</th>
                <td><?php echo htmlspecialchars(ucfirst($appointment['payment_status'])); ?></td>
            </tr>
            <tr>
                <th>Contact:</th>
                <td>Email: <?php echo htmlspecialchars($appointment['pat_email']); ?><br>Phone: <?php echo htmlspecialchars($appointment['pat_phone']); ?></td>
            </tr>
        </table>
    </div>

    <?php if (!empty($prescriptions)): ?>
    <div class="medicines">
        <h3>Prescribed Medicines</h3>
        <ul>
            <?php
            $total = 0;
            foreach ($prescriptions as $med) {
                $subtotal = $med['med_price'] * $med['quantity'];
                $total += $subtotal;
                echo '<li>' . htmlspecialchars($med['med_name']) . ' - Qty: ' . intval($med['quantity']) . ' × RM' . number_format($med['med_price'], 2) . ' = RM' . number_format($subtotal, 2) . '</li>';
            }
            ?>
        </ul>
        <div class="total">Total Medicine Cost: RM <?php echo number_format($total, 2); ?></div>
    </div>
    <?php endif; ?>

    <div class="footer">
        <p>Generated on: <?php echo date('d-M-Y H:i:s'); ?></p>
        <p>&copy; <?php echo date('Y'); ?> Hospital System</p>
    </div>

    <script>
        // Automatically open print dialog when page loads
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>
