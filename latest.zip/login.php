<?php
session_start();
// Redirect logged-in users away from the login page
if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

require 'config/db.php';
$error = '';
$success = '';

// Check for registration success message (This handles the "thank you" notification)
if (isset($_GET['registration_success']) && $_GET['registration_success'] == 1) {
    // The message is now fully contained and styled in the HTML section for clarity, 
    // but we set $success to a truthy value here for consistency with the existing code structure.
    $success = true; 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Hash the input password with MD5 for comparison
    $hash = md5($password);

    $sql = "SELECT user_id, email, password, f_name, user_type FROM `user` WHERE email = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $user_id, $uemail, $stored_hash, $f_name, $user_type);
    
    if (mysqli_stmt_fetch($stmt)) {
        // Compare MD5 hashes
        if ($hash === $stored_hash) {
            $_SESSION['user'] = [
                'user_id' => $user_id,
                'email' => $uemail,
                'f_name' => $f_name,
                'user_type' => $user_type
            ];
            mysqli_stmt_close($stmt);
            // Redirect to respective dashboard
            header('Location: dashboard/' . $user_type . '.php');
            exit;
        } else {
            $error = 'Invalid credentials';
        }
    } else {
        $error = 'Invalid credentials';
    }
    mysqli_stmt_close($stmt);
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
    
    <style>
        /* Styles for the container and alerts */
        .section {
            max-width: 420px;
            margin: 18px auto;
        }
        /* Style for the SUCCESS notification */
        .alert-success {
            color: #155724; 
            background-color: #d4edda; 
            border: 1px solid #c3e6cb; 
            padding: 10px; 
            border-radius: 8px; 
            margin-bottom: 15px;
            font-weight: 500;
        }
        /* Style for the ERROR message (taken from previous inline style) */
        .alert-error {
            color:#b92b2b;
            margin-bottom:8px;
        }
    </style>
</head>
<body>
  <header class="header">
    <div class="brand">Hospital System</div>
    <nav class="nav">
      <a href="index.php">Home</a>
      <button id="theme-toggle" class="btn btn-secondary" style="background: transparent; border: 1px solid #fff; color: #fff; margin-left: 10px;">🌙</button>
    </nav>
  </header>
  <div class="container">
    <div class="section">
      <h2>Login</h2>
      
      <?php 
      // ---------------------------------------------------------------------
      // THANK YOU NOTIFICATION (Updated Display)
      // ---------------------------------------------------------------------
      if ($success): 
      ?>
          <div class="alert-success">
              ✅ Thank you for registering! Your account has been created. Please log in below.
          </div>
      <?php 
      endif;
      ?>

      <?php 
      // Display Login Errors
      if ($error) {
          // Changed to use alert-error class defined in the <style> block
          echo "<div class='alert-error'>".htmlspecialchars($error)."</div>"; 
      }
      ?>
      
      <form method="post">
        <div class="form-group"><label>Email</label><input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"></div>
        <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
        <button class="btn" type="submit">Log In</button>
      </form>

      <p style="margin-top:15px;text-align:center;">
        <a href="register.php" style="color:#007BFF; text-decoration:none;">Don't have an account? Register here.</a>
      </p>
    </div>
  </div>
  <script src="theme.js"></script>
</body>
</html>
