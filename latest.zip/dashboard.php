<?php
session_start();
if (empty($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
$type = $_SESSION['user']['user_type'];
// Correctly redirect to the specific dashboard file inside the dashboard directory
header('Location: dashboard/' . htmlspecialchars($type) . '.php');
exit;
?>