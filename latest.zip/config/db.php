<?php
/**
 * Database Configuration File
 *
 * This file sets up the connection to the MySQL database.
 * NOTE: The provided credentials are for local development (like XAMPP/WAMP).
 * You must create a database named 'hospital_system' for the system to function.
 */

// Database credentials
$host = "localhost";
$user = "root";
$password = ""; // Change this if you have a password
$database = "hospital_systems";

// Create connection
$conn = mysqli_connect($host, $user, $password, $database);

// Check connection and stop execution on failure
if (!$conn) {
    // We die here because the application cannot function without a database connection.
    die("Database Connection failed: " . mysqli_connect_error());
}

// Set character set
mysqli_set_charset($conn, "utf8");

?>