<?php
session_start();
require 'config/db.php'; 

// --- Authentication and Authorization Check ---
if (empty($_SESSION['user'])) {
    header('Location: login.php'); exit;
}
if ($_SESSION['user']['user_type'] !== 'patient') {
    die('Only patients can create appointments.');
}

$uid = $_SESSION['user']['user_id'];

// --- Get Patient ID ---
$sql = "SELECT patient_id FROM patient WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $uid);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $patient_id);
if (!mysqli_stmt_fetch($stmt)) {
    die('Patient profile not found. Please contact admin.');
}
mysqli_stmt_close($stmt);

// --- Load Doctors ---
$doctors = [];
$qr = "SELECT d.doctor_id, u.f_name, u.l_name, d.specialization FROM doctor d JOIN `user` u ON d.user_id = u.user_id";
$res = mysqli_query($conn, $qr);
while ($r = mysqli_fetch_assoc($res)) {
    $doctors[] = $r;
}

$errors = [];
$success = '';
$appt = null;

// --- Handle Appointment Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doctor_id = intval($_POST['doctor_id'] ?? 0);
    $date = $_POST['appointment_date'] ?? '';
    $time = $_POST['appointment_time'] ?? '';
    $symptom = mysqli_real_escape_string($conn, trim($_POST['symptom'] ?? ''));
    $status = 'pending';
    $created_at = date('Y-m-d H:i:s');
    
    // FIX START: Set a default Service_ID as the form does not allow selection
    // Assumes Service_ID 1 ('General Consultation') exists in the services table.
    $service_id = 1; 
    // FIX END
    
    // Basic validation
    if ($doctor_id === 0) $errors[] = 'Please select a doctor.';
    if (empty($date)) $errors[] = 'Date is required.';
    if (empty($time)) $errors[] = 'Time is required.';

    if (empty($errors)) {
        // FIX: Added Service_ID to the column list
        $sql_insert = "INSERT INTO appointment (patient_id, doctor_id, Service_ID, App_Date, App_Time, symptom, status, created_at) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert = mysqli_prepare($conn, $sql_insert);
        
        // FIX: Added 'i' for Service_ID and $service_id to the parameters
        mysqli_stmt_bind_param($stmt_insert, 'iiisssss', $patient_id, $doctor_id, $service_id, $date, $time, $symptom, $status, $created_at);
        
        $inserted = mysqli_stmt_execute($stmt_insert);
        $new_appt_id = mysqli_insert_id($conn);
        mysqli_stmt_close($stmt_insert);

        if ($inserted) {
            $success = 'Appointment request submitted successfully. It is currently pending review.';
            
            $q = "SELECT a.App_ID, a.App_Date, a.App_Time, a.symptom, a.status, ud.f_name AS doc_fname, ud.l_name AS doc_lname, d.specialization,
                         up.f_name AS pat_fname, up.l_name AS pat_lname
                  FROM appointment a
                  JOIN doctor d ON a.doctor_id=d.doctor_id
                  JOIN `user` ud ON d.user_id=ud.user_id
                  JOIN patient p ON a.patient_id=p.patient_id
                  JOIN `user` up ON p.user_id=up.user_id
                  WHERE a.App_ID = ?";
            $stmt_fetch = mysqli_prepare($conn, $q);
            mysqli_stmt_bind_param($stmt_fetch, 'i', $new_appt_id);
            mysqli_stmt_execute($stmt_fetch);
            $res_q = mysqli_stmt_get_result($stmt_fetch);
            $appt = mysqli_fetch_assoc($res_q);
            mysqli_stmt_close($stmt_fetch);

        } else {
            $errors[] = 'Failed to submit appointment request: ' . mysqli_error($conn);
        }
    }
}

// --- Fetch Latest Appointment (If no POST occurred) ---
if (!$appt) {
    $q = "SELECT a.App_ID, a.App_Date, a.App_Time, a.symptom, a.status, ud.f_name AS doc_fname, ud.l_name AS doc_lname, d.specialization,
                 up.f_name AS pat_fname, up.l_name AS pat_lname
          FROM appointment a
          JOIN doctor d ON a.doctor_id=d.doctor_id
          JOIN `user` ud ON d.user_id=ud.user_id
          JOIN patient p ON a.patient_id=p.patient_id
          JOIN `user` up ON p.user_id=up.user_id
          WHERE a.patient_id = ?
          ORDER BY a.created_at DESC LIMIT 1";
    $stmt_fetch_latest = mysqli_prepare($conn, $q);
    mysqli_stmt_bind_param($stmt_fetch_latest, 'i', $patient_id);
    mysqli_stmt_execute($stmt_fetch_latest);
    $res_q = mysqli_stmt_get_result($stmt_fetch_latest);
    $appt = mysqli_fetch_assoc($res_q);
    mysqli_stmt_close($stmt_fetch_latest);
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background-color: #f8f9fa;
            color: #212529;
            line-height: 1.6;
        }

        .header {
            background: #007bff;
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand {
            font-size: 1.5rem;
            font-weight: 700;
        }

        .nav {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }

        .nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: opacity 0.3s;
        }

        .nav a:hover {
            opacity: 0.8;
        }

        .nav .btn {
            background: white;
            color: #007bff;
            padding: 0.5rem 1.5rem;
            border-radius: 6px;
            font-weight: 600;
        }

        .nav .btn:hover {
            opacity: 1;
            background: #f8f9fa;
        }

        .container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.08);
            padding: 2.5rem;
            margin-bottom: 2rem;
        }

        h2 {
            color: #212529;
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 3px solid #007bff;
        }

        h3 {
            color: #212529;
            font-size: 1.35rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            margin-top: 2rem;
        }

        .alert {
            padding: 1rem 1.25rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-weight: 500;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .text-error {
            color: #dc3545;
            padding: 0.5rem;
            background: #fee;
            border-radius: 6px;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #495057;
            font-weight: 600;
            font-size: 0.95rem;
        }

        input[type="date"],
        input[type="time"],
        select,
        textarea {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1rem;
            font-family: inherit;
            transition: all 0.3s;
            background: white;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
        }

        select {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23333' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            padding-right: 2.5rem;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
        }

        .btn {
            background: #007bff;
            color: white;
            padding: 0.875rem 2rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn:hover {
            background: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
        }

        .table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 1.5rem;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            overflow: hidden;
        }

        .table tr:not(:last-child) {
            border-bottom: 1px solid #e0e0e0;
        }

        .table th {
            background: #f8f9fa;
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: #007bff;
            width: 30%;
        }

        .table td {
            padding: 1rem;
            color: #212529;
        }

        .badge {
            display: inline-block;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-pending {
            background: #fef3c7;
            color: #92400e;
        }

        .badge-approved {
            background: #d1fae5;
            color: #065f46;
        }

        .badge-disapproved {
            background: #fee2e2;
            color: #991b1b;
        }

        .badge-cancel {
            background: #e5e7eb;
            color: #4b5563;
        }

        .mt-sm {
            margin-top: 1rem;
        }

        .hr-margin {
            margin: 2.5rem 0;
            border: none;
            border-top: 2px solid #e0e0e0;
        }

        .footer {
            background: #212529;
            color: white;
            text-align: center;
            padding: 2rem;
            margin-top: 3rem;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .nav {
                flex-direction: column;
                gap: 0.5rem;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .card {
                padding: 1.5rem;
            }

            .table th,
            .table td {
                padding: 0.75rem;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
  <header class="header">
    <div class="brand">Hospital System</div>
    <nav class="nav">
      <a href="index.php">Home</a>
      <a href="dashboard/patient.php">Dashboard</a>
      <a href="logout.php" class="btn">Logout</a>
    </nav>
  </header>

  <div class="container">
    <div class="card">
      <h2>Request New Appointment</h2>
      
      <?php 
      if ($success) echo "<div class='alert alert-success'>".htmlspecialchars($success)."</div>";
      if ($errors) foreach($errors as $e) echo "<div class='text-error'>".htmlspecialchars($e)."</div>"; 
      ?>

      <form method="post">
        <div class="form-group">
          <label>Select Doctor</label>
          <select name="doctor_id" required>
            <option value="">-- Select a Doctor --</option>
            <?php foreach($doctors as $d): ?>
              <option value="<?=htmlspecialchars($d['doctor_id'])?>">
                Dr. <?=htmlspecialchars($d['f_name'].' '.$d['l_name'])?> (<?=htmlspecialchars($d['specialization'])?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Preferred Date</label>
                <input type="date" name="appointment_date" required>
            </div>
            <div class="form-group">
                <label>Preferred Time</label>
                <input type="time" name="appointment_time" required>
            </div>
        </div>

        <div class="form-group">
          <label>Symptoms/Reason for Visit</label>
          <textarea name="symptom" rows="4" placeholder="Briefly describe your symptoms or reason for the appointment"></textarea>
        </div>

        <button class="btn" type="submit">Request Appointment</button>
      </form>

      <?php if ($appt): ?>
        <hr class="hr-margin">
        <h3>Latest Appointment Summary</h3>
        <table class="table">
          <tr><th>ID</th><td><?=htmlspecialchars($appt['App_ID'])?></td></tr>
          <tr><th>Doctor</th><td>Dr. <?=htmlspecialchars($appt['doc_fname'].' '.$appt['doc_lname'])?></td></tr>
          <tr><th>Date</th><td><?=htmlspecialchars($appt['App_Date'])?></td></tr>
          <tr><th>Time</th><td><?=htmlspecialchars($appt['App_Time'])?></td></tr>
          <tr><th>Symptoms</th><td><?=htmlspecialchars($appt['symptom'])?></td></tr>
          <tr><th>Status</th>
            <td>
              <?php
                    $status_lower = strtolower($appt['status']);
                    if ($status_lower === 'pending') echo '<span class="badge badge-pending">Pending</span>';
                    elseif ($status_lower === 'approved') echo '<span class="badge badge-approved">Approved</span>';
                    elseif ($status_lower === 'disapproved') echo '<span class="badge badge-disapproved">Disapproved</span>';
                    else echo '<span class="badge badge-cancel">N/A</span>';
              ?>
            </td>
          </tr>
        </table>
        <p class="mt-sm"><button class="btn" onclick="printAppointment()">Print Confirmation</button></p>
      <?php endif; ?>

      <!-- Hidden Print Container -->
      <?php if ($appt): ?>
      <div id="print-container" style="display: none;">
        <div style="max-width: 600px; margin: 30px auto; background: #fff; padding: 20px; border: 1px solid #ccc; box-shadow: 0 0 10px rgba(0,0,0,0.1); font-family: 'Roboto', sans-serif; font-size: 14px;">
          <h2 style="text-align: center; color: #333; font-weight: 700;">Appointment Confirmation Slip</h2>
          <h3 style="font-weight: 500;">Appointment ID: <?=htmlspecialchars($appt['App_ID'])?></h3>

          <table style="width:100%; border-collapse: collapse; margin-top: 20px;">
            <tr><th style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd; width: 30%; background-color: #f2f2f2; color: #007bff; font-weight: 500;">Appointment ID</th><td style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd;"><?=htmlspecialchars($appt['App_ID'])?></td></tr>
            <tr><th style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd; width: 30%; background-color: #f2f2f2; color: #007bff; font-weight: 500;">Patient</th><td style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd;"><?=htmlspecialchars($appt['pat_fname'].' '.$appt['pat_lname'])?></td></tr>
            <tr><th style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd; width: 30%; background-color: #f2f2f2; color: #007bff; font-weight: 500;">Doctor</th><td style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd;">Dr. <?=htmlspecialchars($appt['doc_fname'].' '.$appt['doc_lname'])?></td></tr>
            <tr><th style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd; width: 30%; background-color: #f2f2f2; color: #007bff; font-weight: 500;">Date</th><td style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd;"><?=htmlspecialchars($appt['App_Date'])?></td></tr>
            <tr><th style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd; width: 30%; background-color: #f2f2f2; color: #007bff; font-weight: 500;">Time</th><td style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd;"><?=htmlspecialchars($appt['App_Time'])?></td></tr>
            <tr><th style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd; width: 30%; background-color: #f2f2f2; color: #007bff; font-weight: 500;">Symptoms</th><td style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd;"><?=htmlspecialchars($appt['symptom'])?></td></tr>
            <tr><th style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd; width: 30%; background-color: #f2f2f2; color: #007bff; font-weight: 500;">Status</th>
              <td style="padding: 8px; text-align: left; border-bottom: 1px solid #ddd;">
                <?php
                  $status = strtolower($appt['status']);
                  if ($status=='pending') echo '<span style="background: #fef3c7; color: #92400e; padding: 0.4rem 1rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600; text-transform: uppercase;">Pending</span>';
                  elseif ($status=='approved') echo '<span style="background: #d1fae5; color: #065f46; padding: 0.4rem 1rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600; text-transform: uppercase;">Approved</span>';
                  elseif ($status=='disapproved') echo '<span style="background: #fee2e2; color: #991b1b; padding: 0.4rem 1rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600; text-transform: uppercase;">Disapproved</span>';
                  else echo '<span style="background: #e5e7eb; color: #4b5563; padding: 0.4rem 1rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600; text-transform: uppercase;">N/A</span>';
                ?>
              </td>
            </tr>
          </table>

          <div style="margin-top: 30px;">
            <p>Please arrive 15 minutes prior to your scheduled time.</p>
            <p>This document serves as your official appointment confirmation.</p>
          </div>

          <div style="margin-top: 50px; text-align: center; font-size: 0.9em; color: #777; border-top: 1px solid #eee; padding-top: 10px;">
            123 Health St, Wellness City | Phone: +60 12-345 6789
          </div>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <footer class="footer">
    &copy; <?= date('Y') ?> Hospital System. All rights reserved. | <a href="index.php">Home</a>
  </footer>

  <script>
    function printAppointment() {
      var printContent = document.getElementById('print-container').innerHTML;
      var originalContent = document.body.innerHTML;
      document.body.innerHTML = printContent;
      window.print();
      document.body.innerHTML = originalContent;
    }
  </script>
</body>
</html>
